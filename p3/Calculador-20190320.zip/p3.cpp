#include <iostream>
#include <string>
#include <sstream>
#include "../include/calculator.h"
#include "../include/Number.h"
using namespace std;

int main() {

  string expr_str( "5 4 + 1 -");
  istringstream expresion(expr_str);

  cout << expr_str << " =\n" << *calculador< Number<4,10> >(expresion) << endl;

  expresion.seekg(0, expresion.beg);
  cout << expr_str << " =\n" << *calculador< Number<8,2> >(expresion) << endl;

  expresion.seekg(0, expresion.beg);
  cout << expr_str << " =\n" << *calculador< Number<4,8> >(expresion) << endl;

  cout << "Postfix expresion = " << *calculador< Number<4,16> >(cin) << endl;

  return 0;
}
